# Just Getting Started?

If you have not worked on GNOME Extensions before, but want to, then you can checkout some of these resources to start with.

[GJS Guide](https://gjs.guide/extensions/)

[GJS Docs by GNOME](https://gjs.guide/extensions/)

[LibAdwaita Docs](https://gnome.pages.gitlab.gnome.org/libadwaita/doc/1.2/index.html)

[Gtk4 Docs](https://gnome.pages.gitlab.gnome.org/libadwaita/doc/1.2/index.html)

[Amazing video tutorials by Just Perfection](https://www.youtube.com/playlist?list=PLr3kuDAFECjZhW-p56BoVB7SubdUHBVQT)

[GNOME Extensions Matrix chat room](https://matrix.to/#/#extensions:gnome.org)

Where GJS stands for GNOME JavaScript